
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <div class="navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#" onclick="load_tasks()">Список</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" onclick="new_task()">Новая задача</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/client/logout.php">Выход</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>