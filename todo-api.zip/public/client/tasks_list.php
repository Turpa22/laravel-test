<?php 

$err = '';
$current_host = 'http://' . $_SERVER['HTTP_HOST'];

$current_port = $_SERVER['SERVER_PORT'];
if($current_port<>80){ $current_port = ':' . $current_port; } else { $current_port = ''; }
$current_port = '';

try {
  $current_host = 'http://' . $_SERVER['HTTP_HOST'];
  $current_url = $current_host . $current_port . '/api/tasks';
  
  // Инициализация cURL
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $current_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 5);
  $json_tasks = curl_exec($ch);
  
  // Проверка на ошибки cURL
  if (curl_errno($ch)) {
    throw new Exception(curl_error($ch));
  }
  
  // Закрытие соединения cURL
  curl_close($ch);
  
  $tasks = json_decode($json_tasks);
} catch (Exception $e) {
  $tasks = [];
  $err = $current_url . '   ' . $e->getMessage();
}

$cnt = count($tasks);

// Функция для получения текстового представления статуса
function getStatusText($status) {
  $statuses = [
    1 => 'новая',
    2 => 'в работе',
    3 => 'исполнена',
    4 => 'отклонена',
    5 => 'отменена'
  ];
  
  return $statuses[$status] ?? 'неизвестный статус';
}

if($cnt>0){ ?>
    <table id="tasks_table" class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Название</th>
          <th>Описание</th>
          <th>Дата создания</th>
          <th>Изменение</th>
          <th>Статус</th>
          <th>Действия</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          $i = 1;
          foreach($tasks as $task){ 
            $num = $i;
            $task_id = $task->id;
            $task_title = htmlspecialchars($task->title);
            $task_description = htmlspecialchars($task->description ?? '');
            $task_created = $task->created_at;
            $task_updated = $task->updated_at;
            $task_status = $task->status;
            $task_status_text = htmlspecialchars($task->status_text ?? getStatusText($task->status));
            $i++;
        ?>
        <tr>
          <td><?= $num ?></td>
          <td><?= $task_title ?></td>
          <td><?= $task_description ?></td>
          <td><?= $task_created ?></td>
          <td><?= $task_updated ?></td>
          <td><?= $task_status_text ?></td>
          <td>
            <button class="btn btn-sm btn-primary edit-task" data-id="<?= $task_id ?>">Редактировать</button>
            <button class="btn btn-sm btn-danger delete-task" data-id="<?= $task_id ?>">Удалить</button>
          </td>
        </tr>
        <?php } ?>        
      </tbody>
    </table>
    <?php } else { ?>

      <?php if($err<>''){ ?>
        <p class="tasks__msg"><?= $err ?></p>
      <?php } else { ?>
        <p class="tasks__msg">Список задач пуст! <a href="#" onclick="new_task()">Создать новую задачу</a>.</p>
      <?php } ?>

<?php } ?>