<!DOCTYPE html>
<html lang="ru">
<head>
    <title>TASKS MANAGER</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="/client/css/bootstrap/bootstrap.css"/>
    <link rel="stylesheet" href="/client/css/bootstrap/bootstrap.min.css"/>
    <link rel="stylesheet" href="/client/css/bootstrap/bootstrap-datetimepicker.min.css"/>    
    <link rel="stylesheet" href="/client/css/style.css"/>

    <script language="JavaScript" type="text/javascript" src="/client/js/moment-with-locales.min.js"></script>
    <script language="JavaScript" type="text/javascript" src="/client/js/jquery-3.6.0.min.js"></script>
	  <script language="JavaScript" type="text/javascript" src="/client/js/jquery.cookie.js"></script>
    <script language="JavaScript" type="text/javascript" src="/client/js/bootstrap/bootstrap.min.js"></script>
	  <script language="JavaScript" type="text/javascript" src="/client/js/bootstrap/bootstrap-datetimepicker.min.js"></script>
	  <script language="JavaScript" type="text/javascript" src="/client/js/jquery.maskedinput.min.js"></script>

    <script language="JavaScript" type="text/javascript" src="/client/js/main.js"></script>
  </head>
  <body>

<?php
  include_once 'menu.php';
?>